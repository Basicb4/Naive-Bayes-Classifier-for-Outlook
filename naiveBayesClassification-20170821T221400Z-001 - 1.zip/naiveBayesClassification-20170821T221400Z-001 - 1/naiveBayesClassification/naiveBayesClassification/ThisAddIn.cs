﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace naiveBayesClassification
{
    public partial class ThisAddIn
    {

        Outlook.NameSpace outlookNameSpace;
        Outlook.MAPIFolder inbox;
        Outlook.Items items;
        Outlook.Inspectors inspectors;
        BayesClassifier.Classifier m_Classifier = new BayesClassifier.Classifier();
        Microsoft.Office.Interop.Outlook.MAPIFolder subFolder = null;
        Microsoft.Office.Interop.Outlook.MailItem item = null;
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            string cat1File = "C:/Users/Bradley/Desktop/received.txt";
            string cat2File = "C:/Users/Bradley/Desktop/malicious.txt";


            // m_Classifier.TeachCategory("Cat1", new System.IO.StreamReader(cat1File));
            // m_Classifier.TeachCategory("Cat2", new System.IO.StreamReader(cat2File));
            m_Classifier.TeachPhrases("Cat1", new string[] { "Hi", "Hello" });
            m_Classifier.TeachPhrases("Cat2", new string[] { "Hi", "HoHo" });
            outlookNameSpace = this.Application.GetNamespace("MAPI");
            inbox = outlookNameSpace.GetDefaultFolder(
                    Microsoft.Office.Interop.Outlook.
                    OlDefaultFolders.olFolderInbox);

            items = inbox.Items;
            items.ItemAdd +=
                new Outlook.ItemsEvents_ItemAddEventHandler(items_ItemAdd);
            
            //sortAllIttems();

        }
        public void sortAllIttems()
        {
            subFolder = inbox; // or use folder.Folders["Folder Name"];

            Console.WriteLine("Folder Name: {0}, EntryId: {1}", subFolder.Name, subFolder.EntryID);
            Console.WriteLine("Num Items: {0}", subFolder.Items.Count.ToString());

            for (int i = 1; i <= subFolder.Items.Count; i++)
            {
                try
                {
                    item = (Outlook.MailItem)subFolder.Items[i];
                    if (item != null)
                    {
                        try
                        {
                            String classificationBody = item.Body.ToString();
                            Console.WriteLine("Okay made it here");
                            Stream s = GenerateStreamFromString(classificationBody);
                            StreamReader sr = new StreamReader(s);
                            Dictionary<string, double> score = m_Classifier.Classify(sr);
                            Outlook.MAPIFolder cat1Folder = inbox.Folders["Cat1"];
                            Outlook.MAPIFolder cat2Folder = inbox.Folders["Cat2"];
                            double value1 = score["Cat1"];
                            double value2 = score["Cat2"];
                            if (value1 > value2)
                            {
                                item.Move(cat1Folder);
                            }

                            else if (value2 > value1)
                            {
                                item.Move(cat2Folder);
                            }
                        }

                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                        }


                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }

            }
      
        }

        void items_ItemAdd(object Item) { 
   
            Outlook.MailItem mail = (Outlook.MailItem)Item;
            if (Item != null)
            {
                MessageBox.Show("Detect email was added");
                String classificationBody = mail.Body.ToString();
                MessageBox.Show(classificationBody);
                Stream s = GenerateStreamFromString(classificationBody);
                StreamReader sr = new StreamReader(s);
                Dictionary<string, double> score = m_Classifier.Classify(sr);
                Outlook.MAPIFolder cat1Folder = inbox.Folders["Cat1"];
                Outlook.MAPIFolder cat2Folder = inbox.Folders["Cat2"];
                double value1 = score["Cat1"];
                double value2 = score["Cat2"];
                if (value1 > value2)
                {
                    MessageBox.Show("Category 1");
                    mail.Move(cat1Folder);
                }

                else if(value2 > value1)
                {
                    MessageBox.Show("Category 2");
                    mail.Move(cat2Folder);
                }

                else
                {
                    MessageBox.Show("They are equal");
                }
            }
        }

        public Stream GenerateStreamFromString(string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // Note: Outlook no longer raises this event. If you have code that 
            //    must run when Outlook shuts down, see http://go.microsoft.com/fwlink/?LinkId=506785
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
